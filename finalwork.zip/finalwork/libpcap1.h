#ifndef LIBPCAP1_H
#define LIBPCAP1_H

#endif // LIBPCAP1_H
class libpcap1
{
public:
    libpcap1() {}
    static char* net_interface;
    static char* net_ip_string;
    static char* net_mask_string;
};
