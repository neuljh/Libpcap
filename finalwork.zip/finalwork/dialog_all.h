#ifndef DIALOG_ALL_H
#define DIALOG_ALL_H

#include <QDialog>

namespace Ui {
class Dialog_all;
}

class Dialog_all : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_all(QWidget *parent = nullptr);
    ~Dialog_all();
    static int index;

private slots:
    void on_pushButton_clicked();

    void on_btn_next_clicked();

private:
    Ui::Dialog_all *ui;
};

#endif // DIALOG_ALL_H
