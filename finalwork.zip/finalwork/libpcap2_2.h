#ifndef LIBPCAP2_2_H
#define LIBPCAP2_2_H

#endif // LIBPCAP2_2_H
#include<string>
using namespace std;

class libpcap2_2
{
public:
    libpcap2_2() {}
    static string res;
    static int number;
};
