#ifndef LIBPCAP2_1_H
#define LIBPCAP2_1_H

#endif // LIBPCAP2_1_H

#include<string>
using namespace std;

class libpcap2_1{
public:
    static string net_interface;
    static int length;
};
